﻿using System;
public class Program
{
    public static void Main()
    {
        int num, r, sum = 0, t;

        Console.Write("Afiseaza numarul invers");


        Console.Write("Introduceti un nuamar: ");
        num = Convert.ToInt32(Console.ReadLine());

        for (t = num; t != 0; t = t / 10)
        {
            r = t % 10;
            sum = sum * 10 + r;
        }
        Console.Write("Numarul invers este {0} ", sum);
    }
}
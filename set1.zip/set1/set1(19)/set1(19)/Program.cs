﻿//Determinati daca un numar e format doar cu 2 cifre care se pot repeta
using System;
class Program
{
    static int countRepeatingDigits(int N)
    {
        int res = 0;
        int[] cnt = new int[10];

        while (N > 0)
        {
            int rem = N % 10;

            cnt[rem]++;

            N = N / 10;
        }

        for (int i = 0; i < 10; i++)
        {
            if (cnt[i] > 1)
            {
                res++;
            }
        }

        return res;
    }

    public static void Main(String[] args)
    {
        int N = 2322233;

        Console.WriteLine(countRepeatingDigits(N));
    }
}


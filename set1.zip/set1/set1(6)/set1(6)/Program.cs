﻿//Determinati daca trei numere pozitive a, b si c pot fi lungimile laturilor unui triunghi. 
using System;

class Program
{
    public static int lat(int a, int b, int c)
                                    
    {
        if (a + b <= c || a + c <= b ||
                            b + c <= a)
            return 0;
        else
            return 1;
    }
    public static void Main()
    {
        int a = 9, b = 12, c = 7;
        if ((lat(a, b, c)) == 1)
            Console.Write("Aceste numere pot fi laturile unui triunghi");
        else
            Console.Write("Aceste numere nu pot fi laturile unui triunghi");

    }
}


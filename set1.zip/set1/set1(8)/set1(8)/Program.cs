﻿//Se dau doua variabile numerice a si b ale carori valori sunt date de intrare. Se cere sa se inverseze valorile lor fara a folosi alte variabile suplimentare. 
using System;
class Program
{
    public static void Main()
    {
        int x = 20;
        int y = 10;

        x = x + y;
        y = x - y;
        x = x - y;
        Console.WriteLine("Dupa schimbare: x = " + x
                          + ", y = " + y);
    }
}
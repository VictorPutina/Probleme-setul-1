﻿//Determinati daca n se divide cu k, unde n si k sunt date de intrare. 
using System;

class Program
{
    static int countDivisors(int n, int k)
    {
        int count = 0, i;

        for (i = 1; i <= n; i++)
        {

            if (n % i == 0 && i % k == 0)
            {
                count++;
            }
        }
        return count;
    }
    public static void Main()
    {
        int n = 20, k = 3;

        Console.WriteLine(countDivisors(n, k));
    }
}

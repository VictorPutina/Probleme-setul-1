﻿//Determinati cate numere integi divizibile cu n se afla in intervalul [a, b]
using System;

public class Program
{
    static int countDivisibles(int a, int b, int d)
    {
        int counter = 0;
        for (int i = a; i <= b; i++)
            if (i % d == 0)
                counter++;

        return counter;
    }
    public static void Main()
    {

        int a = 50, b = 120, d = 50;


        Console.WriteLine(countDivisibles(a, b, d));
    }
}


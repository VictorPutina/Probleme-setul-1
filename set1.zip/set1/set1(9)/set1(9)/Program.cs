﻿//Afisati toti divizorii numarului n.
using System;
class Program
{
    static void printDivisors(int n)
    {
        for (int i = 1; i <= n; i++)
            if (n % i == 0)
                Console.Write(i + " ");
    }
    public static void Main()
    {
        Console.Write("Divizorii lui"," 80 sunt: ");
        printDivisors(80); ;
    }
}


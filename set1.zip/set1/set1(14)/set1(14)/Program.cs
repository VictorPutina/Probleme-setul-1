﻿//Determianti daca un numar n este palindrom. (un numar este palindrom daca citit invers obtinem un numar egal cu el
using System;

class Program
{
    public static int oneDigit(int num)
    {
        if ((num >= 0) && (num < 10))
            return 1;
        else
            return 0;
    }

    public static int esPalindrom(int num,
                                int dNum)
    {
        if (oneDigit(num) == 1)
            if (num == (dNum) % 10)
                return 1;
            else
                return 0;

        if (esPalindrom((int)(num / 10), dNum) == 0)
            return -1;

        dNum = (int)(dNum / 10);

        if (num % 10 == (dNum) % 10)
            return 1;
        else
            return 0;
    }

    public static int ePal(int num)
    {

        if (num < 0)
            num = (-num);

        int dNum = (num); 

        return esPalindrom(num, dNum);
    }

    public static void Main()
    {
        int n = 789987;
        if (ePal(n) == 0)
            Console.WriteLine("DA");
        else
            Console.WriteLine("NU");

        n = 23;
        if (ePal(n) == 0)
            Console.WriteLine("DA");
        else
            Console.WriteLine("NU");

        n = 33;
        if (ePal(n) == 1)
            Console.WriteLine("DA");
        else
            Console.WriteLine("NU");

        n = 2333;
        if (ePal(n) == 0)
            Console.WriteLine("DA");
        else
            Console.WriteLine("NU");
    }
}


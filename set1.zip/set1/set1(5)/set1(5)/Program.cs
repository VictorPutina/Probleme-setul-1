﻿//Extrageti si afisati a k-a cifra de la sfarsitul unui numar. Cifrele se numara de la dreapta la stanga. 
using System;

public class Program
{
    public static int primaCifra(int n)
    {
        while (n >= 10)
            n /= 10;
        return n;
    }
    public static int ultimaCifra(int n)
    {
        return (n % 10);
    }
    public static void Main()
    {
        int n = 2023;
        Console.WriteLine(primaCifra(n) + " "
        + ultimaCifra(n));
    }
}

﻿//Determianti cati ani bisecti sunt intre anii y1 si y2.
using System;

class Program
{
    static int calNum(int year)
    {
        return (year / 4) - (year / 100) +
                            (year / 400);
    }
    static void leapNum(int t, int u)
    {
        t--;
        int num1 = calNum(u);
        int num2 = calNum(t);
        Console.Write(num1 - num2 + "\n");
    }

    public static void Main(String[] args)
    {
        int t1= 1, u1 = 400;
        leapNum(t1, u1);

        int t2 = 400, u2 = 2000;
        leapNum(t2, u2);
    }
}


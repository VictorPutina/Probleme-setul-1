﻿//Determianti cel mai mare divizor comun si cel mai mic multiplu comun a doua numere. Folositi algoritmul lui Euclid.
using System;
public class Program
{
    static int gcd(int a, int b)
    {
        int result = Math.Min(a, b);
        while (result > 0)
        {
            if (a % result == 0 && b % result == 0)
            {
                break;
            }
            result--;
        }
        return result;
    }
    public static void Main(string[] args)
    {
        int a = 125, b = 77;
        Console.WriteLine("GCD al " + a + " si " + b + " este " + gcd(a, b));
    }
}


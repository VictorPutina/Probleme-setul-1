﻿//Se dau 3 numere. Sa se afiseze in ordine crescatoare
using System;
class Program
{
    public static void Main()
    {
        int[] a = { 5, 6, 4 };

        Array.Sort(a);

        for (int i = 0; i < 3; i++)
            Console.Write(a[i] + " ");
    }
}
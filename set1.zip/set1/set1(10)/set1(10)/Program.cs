﻿//Test de primalitate: determinati daca un numar n este prim.
using System;
public class program
{
    public static bool prime(int num)
    {
        for (int i = 2; i < num; i++)
            if (num % i == 0)
                return false;
        return true;
    }
    public static void Main()
    {
        Console.Write("Introduceti un numar : ");
        int n = Convert.ToInt32(Console.ReadLine());

        if (prime(n))
            Console.WriteLine(n + " este un numar prim");
        else
            Console.WriteLine(n + " nu este un numar prim");
    }
}

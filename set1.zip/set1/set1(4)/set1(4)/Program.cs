﻿//Detreminati daca un an y este an bisect. 
using System;
public class Program
{
    public static void Main()
    {
        int an;
        Console.Write("Determinati dacă un anumit an este sau nu bisect:\n");
        Console.Write("Intruduceti un an : ");
        an = Convert.ToInt32(Console.ReadLine());

        if ((an % 400) == 0)
            Console.WriteLine("{0} este un an bisect.\n", an);
        else if ((an % 100) == 0)
            Console.WriteLine("{0} nu este un an bisect.\n", an);
        else if ((an % 4) == 0)
            Console.WriteLine("{0} este un an bisect.\n", an);
        else
            Console.WriteLine("{0} nu este un an bisect.\n", an);
    }
}
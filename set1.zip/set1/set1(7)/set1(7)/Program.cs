﻿//(Swap) Se dau doua variabile numerice a si b ale carori valori sunt date de intrare. Se cere sa se inverseze valorile lor.
using System;
public class Program
{
    public static void Main(string[] args)
    {
        int a = 8, b = 9;
        Console.WriteLine("Inainte de schimb a="+ a + " b="+ b);
        a = a * b; //a=72 (8*9)      
        b = a / b; //b=8 (72/9)      
        a = a / b; //a=9 (72/8)    
        Console.Write("Dupa schimb a="+ a + " b="+ b);
    }
}